// Lab 10 - Task 02: Browser history using a linked-list stack
#include <iostream>
#include <string>
using namespace std;

struct Node {
    string data;
    Node* next;
};

Node* top = NULL;

bool isEmpty() {
    return top == NULL;
}

void push(string page) {
    Node* newNode = new Node;
    newNode->data = page;
    newNode->next = top;
    top = newNode;

    cout << page << " visited successfully." << endl;
}

void back() {
    if (top == NULL || top->next == NULL) {
        cout << "Cannot go back" << endl;
        return;
    }

    Node* temp = top;
    top = top->next;
    delete temp;

    cout << "Current page: " << top->data << endl;
}

void peek() {
    if (isEmpty())
        cout << "No page visited." << endl;
    else
        cout << "Current page: " << top->data << endl;
}

void display() {
    if (isEmpty()) {
        cout << "History is empty." << endl;
        return;
    }

    Node* current = top;

    cout << "Browser History:" << endl;

    while (current != NULL) {
        cout << current->data << endl;
        current = current->next;
    }
}

void clearStack() {
    while (top != NULL) {
        Node* temp = top;
        top = top->next;
        delete temp;
    }
}

int main() {
    int choice;
    string page;

    do {
        cout << "\n1. Visit Page";
        cout << "\n2. Back";
        cout << "\n3. Current Page";
        cout << "\n4. History";
        cout << "\n0. Exit";

        cout << "\nEnter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter page name: ";
                cin >> page;
                push(page);
                break;

            case 2:
                back();
                break;

            case 3:
                peek();
                break;

            case 4:
                display();
                break;

            case 0:
                clearStack();
                cout << "Goodbye!" << endl;
                break;

            default:
                cout << "Invalid choice!" << endl;
        }

    } while (choice != 0);

    return 0;
}
