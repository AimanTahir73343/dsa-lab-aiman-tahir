// Lab 10 - Task 04: Decimal to binary conversion using a stack
#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* top = NULL;

bool isEmpty() {
    return top == NULL;
}

void push(int value) {
    Node* newNode = new Node;
    newNode->data = value;
    newNode->next = top;
    top = newNode;
}

int pop() {
    if (isEmpty()) {
        return -1;
    }

    Node* temp = top;
    int value = temp->data;

    top = top->next;
    delete temp;

    return value;
}

int main() {
    int num;

    cout << "Enter decimal number: ";
    cin >> num;

    if (num == 0) {
        cout << "Binary: 0" << endl;
    }
    else {
        while (num > 0) {
            int remainder = num % 2;
            push(remainder);
            num = num / 2;
        }

        cout << "Binary: ";

        while (!isEmpty()) {
            cout << pop();
        }

        cout << endl;
    }

    return 0;
}
